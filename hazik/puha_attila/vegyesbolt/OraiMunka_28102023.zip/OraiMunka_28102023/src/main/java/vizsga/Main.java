package vizsga;

import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;


public class Main {
    public static void main(String[] args) throws IOException {

        Connection c = null;
        Statement stmt = null;
        Feladatok f = new Feladatok();
        FileWriter myWriter1 = new FileWriter("vizsgaPAL.txt");
        FileWriter myWriter2 = new FileWriter("createCSV_PAL.csv");

        try {
            Class.forName("org.postgresql.Driver");
            c = DriverManager.getConnection(
                    "jdbc:postgresql://localhost:5432/postgres?currentSchema=public",
                    "postgres",
                    "PAL1995+");
            c.setAutoCommit(false);
            System.out.println("Opened database successfully");
            for (Lekerdezes l : f.getKerdesek()){
                ArrayList<String> eredmeny = new ArrayList<>();
                PreparedStatement st = c.prepareStatement(l.getSqlParancs());
                ResultSet result = st.executeQuery();

                while (result.next()) {
                    String sor = "";
                    for (int oszlopSzam=1;oszlopSzam<=l.getOszlopSzam();oszlopSzam++){
                        //System.out.print(result.getString(oszlopSzam)+"\t");
                        sor = sor + result.getString(oszlopSzam) +"\t";
                        //myWriter.write(sor);
                    }
                    eredmeny.add(sor);
                    System.out.println(sor);
                }
                System.out.println("Kérdés: " + l.getKerdes());
                System.out.println("Script: " + l.getSqlParancs());
                System.out.println("Eredmény: " + eredmeny.stream().count());
                myWriter1.write("Kérdés: " + l.getKerdes() + "\n");
                myWriter1.write("Script: " + l.getSqlParancs() + "\n");
                myWriter1.write("Eredmény: " + eredmeny.stream().count() + "\n" + "\n" );
                int sorSzam = 1;
                for (String sor : eredmeny){
                    myWriter1.write(sorSzam + ".\t" + sor + "\n");
                    sorSzam++;
                }
                myWriter1.write("\n");
                System.out.println("************************");
            }
            myWriter1.close();
            for (Lekerdezes l : f.getKerdesek()){
                ArrayList<String> eredmeny = new ArrayList<>();
                PreparedStatement st = c.prepareStatement(l.getSqlParancs());
                ResultSet result = st.executeQuery();

                while (result.next()) {
                    String sor = "";
                    for (int oszlopSzam=1;oszlopSzam<=l.getOszlopSzam();oszlopSzam++){
                        //System.out.print(result.getString(oszlopSzam)+"\t");
                        sor = sor + result.getString(oszlopSzam) +"\t";
                        //myWriter.write(sor);
                    }
                    eredmeny.add(sor);
                    System.out.println(sor);
                }
                System.out.println(eredmeny.stream().count());
                for (String sor : eredmeny){
                    myWriter2.write(sor + "\n");
                    ;
                }
                myWriter2.write("\n");
                System.out.println("************************");
            }
            myWriter2.close();
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }
    }
}