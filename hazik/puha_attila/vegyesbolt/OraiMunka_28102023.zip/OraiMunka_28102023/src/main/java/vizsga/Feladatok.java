package vizsga;

import java.util.ArrayList;
import java.util.List;

public class Feladatok {

    ArrayList<Lekerdezes> kerdesek = new ArrayList<>();

    public Feladatok(){
        kerdesek.add(new Lekerdezes(
                5,
                "Irassa ki az egyes autók típusát, a vásárlás idejét és a beszerzési árat!",
                "select tipusok_id, vasarlas_datuma, ar from autok",
                3));
        kerdesek.add(new Lekerdezes(
                6,
                "Irassa ki SELECT utasítással az AUTOK táblából az összes autó rendszámát, típusát és árát! A kiírás az ár szerinti csökkenő sorrendben történjen!",
                "select a.rendszam, t.tipus_nev, a.ar from autok a join tipusok t on a.tipusok_id=t.id;",
                3));
        kerdesek.add(new Lekerdezes(
                7,
                "Irassa ki az AUTOK táblából az autók rendszámát és árát!",
                "select rendszam, ar from autok;",
                2));
        kerdesek.add(new Lekerdezes(
                8,
                "Irassa ki az 1350000 Ft-nál drágábban vásárolt autók típusát és árát!",
                "select distinct tipusok_id, ar from autok where ar > 1350000;",
                2));
        kerdesek.add(new Lekerdezes(
                9,
                "Irassa ki az 1350000 Ft-nál drágábban vásárolt autók típusát, árát és autócsoport nevét a csoport szerint növekvő, az ár szerint csökkenő sorrendben!",
                "select tipusok_id, ar, auto_csop_id from autok where ar > 1350000 order by auto_csop_id, ar desc;",
                3));
        kerdesek.add(new Lekerdezes(
                10,
                "Irassa ki az összes olyan autó rendszámát és típusát, amelyek nem az EXTRA autócsoporthoz tartoznak!",
                "select rendszam, tipusok_id from autok where auto_csop_id != 2;",
                2));
        kerdesek.add(new Lekerdezes(
                11,
                "Irassa ki azon autók adatait az AUTOK táblából, amelyek 9000 km nél többet futottak és áruk 1000000 Ft alatt van!",
                "select * from autok a where futott_km > 9000 and ar < 1000000;",
                11));
        kerdesek.add(new Lekerdezes(
                12,
                "Irassa ki az összes kifizetett rendelésre vonatkozó adatot!",
                "select * from rendeles r where fizetes = 'Y';",
                13));
        kerdesek.add(new Lekerdezes(
                13,
                "Irassa ki az 1994. március 1. előtti megrendelésekben szereplő adatokat!",
                "select * from rendeles r where rendeles_datum < '1994-03-01';",
                13));
        kerdesek.add(new Lekerdezes(
                14,
                "Irassa ki az 1994. március 1. után esedékes, nem kifizetett megrendelés adatokat!",
                "select * from rendeles r where rendeles_datum > '1994-03-01' and fizetes = 'N';",
                13));
        kerdesek.add(new Lekerdezes(
                15,
                "Irassa ki az összes olyan autó rendszámát, típusát és a futott kilométert, amelyek a 20-as részleghez tartoznak!",
                "select rendszam, tipusok_id, futott_km from autok a where reszleg_id = '2';",
                3));
        kerdesek.add(new Lekerdezes(
                16,
                "Irassa ki az összes olyan autó adatait, amelyet 1994. január 1. előtt vásároltak!",
                "select * from autok a where vasarlas_datuma < '1994-01-01';",
                11));
        kerdesek.add(new Lekerdezes(
                17,
                "Irassa ki az ALKALMAZOTT táblából a munkatársak nevét, beosztását és fizetését, fizetés szerint csökkenő (növekvő) sorrendben!",
                "select alk_nev, beosztas, fizetes from alkalmazott a order by fizetes desc;",
                3));
        kerdesek.add(new Lekerdezes(
                18,
                "Irassa ki az ALKALMAZOTT tábla tartalmát beosztás szerint növekvő, ezen belül fizetés szerint csökkenő sorrendben!",
                "select * from alkalmazott a order by beosztas, fizetes desc;",
                8));
        kerdesek.add(new Lekerdezes(
                19,
                "Irassa ki az ALKALMAZOTT táblából az összes különböző beosztás nevét!",
                "select distinct beosztas  from alkalmazott; ",
                1));
        kerdesek.add(new Lekerdezes(
                20,
                "Irassa ki az'ELADÓ' és'SZERELŐ' foglalkozású dolgozókat fizetés szerint csökkenő sorrendben!",
                "select alk_nev from alkalmazott where beosztas = 'ELADO'or beosztas = 'SZERELO' order by fizetes desc;",
                1));
        kerdesek.add(new Lekerdezes(
                21,
                "Irassa ki az ALKALMAZOTT táblából azokat, akiknek a fizetése nagyobb 50000-nél vagy a beosztásuk 'SZERELŐ' a belépés dátuma szerinti sorrendben!",
                "select * from alkalmazott a where fizetes > 5000 or beosztas = 'SZERELO' order by belepes;",
                8));
        kerdesek.add(new Lekerdezes(
                22,
                "Irassa ki azokat, akiknek a fizetése 60000-nél kisebb vagy 100000 nél nagyobb!",
                "select * from alkalmazott a where fizetes < 60000 or fizetes > 100000;",
                8));
        kerdesek.add(new Lekerdezes(
                23,
                "Irassa ki az ALKALMAZOTT táblából azokat a dolgozókat, akik a 20-as vagy 50-es kódú részlegben dolgoznak!",
                "select * from alkalmazott a where reszleg_id = '2' or reszleg_id = '5';",
                8));
        kerdesek.add(new Lekerdezes(
                24,
                "Irassa ki a 30-nál nagyobb kódú munkahelyen dolgozók adatait!",
                "select * from alkalmazott a where reszleg_id > '3';",
                8));
        kerdesek.add(new Lekerdezes(
                25,
                "Irassa ki a vidéki (nem budapesti) részlegek adatait!",
                "select * from reszleg r where reszleg_cim != 'BUDAPEST';",
                4));
        kerdesek.add(new Lekerdezes(
                26,
                "Irassa ki városnév szerint rendezve az ügyfelek és városuk nevét!",
                "select ugyfel_nev, varos from ugyfelek u order by varos;",
                2));
        kerdesek.add(new Lekerdezes(
                27,
                "Irassa ki azon ügyfelek adatait, akik készpénzzel (átutalással) fizetnek!",
                "select * from ugyfelek u where fizetesi_mod = 'K';",
                9));
        kerdesek.add(new Lekerdezes(
                28,
                "Irassa ki azon rendelések adatait, amelyeknél a kölcsönzési idő 1 hétnél hosszabb!",
                "select * from rendeles r where napok > 7;",
                13));
        kerdesek.add(new Lekerdezes(
                29,
                "Irassa ki azon rendelésekre vonatkozó adatokat, amelyeket már kifizettek!",
                "select * from rendeles r where fizetes = 'Y';",
                13));
        kerdesek.add(new Lekerdezes(
                30,
                "Irassa ki az AUTO_CSOP tábla tartalmát kilométer díj szerint csökkenő sorrendben!",
                "select * from auto_csop order by km_dij desc;",
                4));
        kerdesek.add(new Lekerdezes(
                31,
                "Irassa ki az egyes autótípusoknál a tipus név mellé a kötelező karbantartás (szervízbe vitel) kilométer intervallumát! A kiírás a típus neve szerint legyen rendezve!",
                "select tipus_nev, szerviz_km from tipusok order by tipus_nev;",
                2));
        kerdesek.add(new Lekerdezes(
                32,
                "Irassa ki azon autók adatait, amelyek 100000 kilométernél többet futottak!",
                "select * from autok a where futott_km > 100000;",
                11));
        kerdesek.add(new Lekerdezes(
                33,
                "Készítsen listát a kiadható autók adatairól!",
                "select * from autok a where allapot = 'A';",
                11));
        kerdesek.add(new Lekerdezes(
                34,
                "Készítsen listát azokról az autókról, amelyek szervízben vannak, vagy karbantartásra várnak és ezért nem adhatók ki kölcsönzésre!",
                "select * from autok a where allapot = 'S' or allapot = 'X';",
                11));
        kerdesek.add(new Lekerdezes(
                35,
                "Készítsen név szerint rendezett listát az ügyfelekről tárolt adatokról!",
                "select * from ugyfelek u order by ugyfel_nev;",
                9));
        kerdesek.add(new Lekerdezes(
                36,
                "Irassa ki a LUXUS autócsoporthoz tartozó autók rendszámát és típusát!",
                "select rendszam, tipusok_id from autok a where auto_csop_id = 3;",
                2));
        kerdesek.add(new Lekerdezes(
                37,
                "Irassa ki azokat az autó típusokat, melyeket 15000 kilométerenként kell szervízbe vinni!",
                "select tipus_nev from tipusok t where szerviz_km = 15000;",
                1));
        kerdesek.add(new Lekerdezes(
                38,
                "Készítsen listát azokról a városokról, ahol az autókölcsönzőnek részlege van!",
                "select distinct reszleg_cim from reszleg r;",
                1));
        kerdesek.add(new Lekerdezes(
                39,
                "Irassa ki a debreceni ügyfelek adatait!",
                "select * from ugyfelek u where varos = 'DEBRECEN';",
                9));
        kerdesek.add(new Lekerdezes(
                40,
                "Irassa ki a rendeléseknél kapcsolatot tartó személyek nevét névsor szerint rendezve!",
                "select rendelo_szemely from rendeles r order by rendelo_szemely;",
                1));
        kerdesek.add(new Lekerdezes(
                41,
                "Irassa ki az alkalmazottak nevét, beosztását és jövedelmét (fizetés + prémium) névsor szerinti sorrendben!",
                "select alk_nev, beosztas,fizetes + coalesce (premium,0) as \"emelt fizetés\" from alkalmazott a order by alk_nev;",
                3));
        kerdesek.add(new Lekerdezes(
                42,
                "Irassa ki azokat a dolgozókat, akiknek fizetése 50000 és 100000 Ft közötti!",
                "select * from alkalmazott a where fizetes > 50000 and fizetes < 100000;",
                8));
        kerdesek.add(new Lekerdezes(
                43,
                "Készítsen listát a 120000 és 200000 közötti kilométert futott autókról!",
                "select * from autok a where futott_km > 120000 and futott_km < 200000;",
                11));
        kerdesek.add(new Lekerdezes(
                44,
                "Irassa ki azon dolgozók adatait, akiknek a beosztása 'TELEPHELYVEZETŐ' vagy 'SZERELŐ'!",
                "select * from alkalmazott a where beosztas = 'TELEPHELYVEZETO' or beosztas = 'SZERELO';",
                8));
        kerdesek.add(new Lekerdezes(
                45,
                "Irassa ki a 10, 20 vagy 60-as telepen dolgozók adatait!",
                "select * from alkalmazott a where reszleg_id = '1' or reszleg_id = '2' or reszleg_id = '6';",
                8));
        kerdesek.add(new Lekerdezes(
                46,
                "Irassa ki azon dolgozók adatait akiknek a neve 'H' betűvel kezdődik!",
                "select * from alkalmazott a where alk_nev like 'H_%';",
                8));
        kerdesek.add(new Lekerdezes(
                47,
                "Irassa ki az ALKALMAZOTT tábla tartalmát azokra, akiknek a nevében 'O' betű szerepel!",
                "select * from alkalmazott a where alk_nev like '%O%';",
                8));
        kerdesek.add(new Lekerdezes(
                48,
                "Irassa ki azon alkalmazottak adatait, akik nevének második betűje az 'O' betű!",
                "select * from alkalmazott a where alk_nev like '_O_%';",
                8));
        kerdesek.add(new Lekerdezes(
                49,
                "Irassa ki azokat a részlegre vonatkozó adatokat, amelyek nevében nem szerepel az 'AUTO'!",
                "select * from reszleg r where reszleg_nev not like '%AUTO%';",
                4));
        kerdesek.add(new Lekerdezes(
                50,
                "Irassa ki azon alkalmazottak adatait, akik a 10-es részlegben dolgoznak és beosztásuk 'ELADÓ', vagy nem kaptak prémiumot!",
                "select * from alkalmazott a where (reszleg_id = '1' and beosztas = 'ELADO') or premium is null;",
                8));
        kerdesek.add(new Lekerdezes(
                51,
                "Készítsen listát azon dolgozók adatairól, akik fizetése 60000 és 90000 Ft közötti és beosztásuk nem 'TELEPHELYVEZETŐ' vagy ELADÓ!",
                "select * from alkalmazott a where fizetes between 60000 and 90000 and beosztas not in ('TELEPHELYVEZETO','ELADO');",
                8));
        kerdesek.add(new Lekerdezes(
                52,
                "Készítsen listát azokról a dolgozókról, akik nem kaptak prémiumot!",
                "select * from alkalmazott a where premium is null;",
                8));
        kerdesek.add(new Lekerdezes(
                53,
                "Irassa ki azon dolgozók adatait, akiknek a fizetése kisebb, mint a prémiumuk kétszerese!",
                "select * from alkalmazott a where fizetes < 2*coalesce (premium,0);",
                8));
        kerdesek.add(new Lekerdezes(
                54,
                "Irassa ki azokat a rendelés adatokat, amelyekben a kölcsönzés végén a kilométeróra állása legalább 1000-rel mutat többet, mint az elején vagy a kölcsönzött napok száma nagyobb 10-nél!",
                "select * from rendeles r where km_veg - km_kezdet >= 1000 or napok > 10;",
                13));
        kerdesek.add(new Lekerdezes(
                56,
                "Irassa ki azon megrendelések adatait, amelyekben a kölcsönzött (nem kifizetett) autó típusnevében szerepel a RENAULT szó!",
                "select * from rendeles r join tipusok t on r.tipusok_id = t.id where tipus_nev like '%RENAULT%' and kolcson_dij is null; ",
                18));
        kerdesek.add(new Lekerdezes(
                57,
                "Készítsen listát azon autók adatairól, amelyek kilométer díja 100 és 300 Ft között van és napi kölcsönzési díja kevesebb, mint 6000 Ft!",
                "select * from auto_csop ac where (km_dij between 100 and 300) and (napi_dij < 6000);",
                4));
        kerdesek.add(new Lekerdezes(
                58,
                "Listázza ki azokat az autótípus jellemzőket, amelyek az E-vel kezdődő nevű autócsoportba tartoznak!",
                "select * from tipusok t join auto_csop ac on t.auto_csop_id = ac.id where auto_csop_nev like 'E_%';",
                9));
        kerdesek.add(new Lekerdezes(
                59,
                "Irassa ki azon autótípus adatokat, ahol a kötelező szervízek intervalluma 10000 és 15000 kilométer között van és az autó típusneve nem a RENAULT szóval kezdődik!",
                "select * from tipusok t where (szerviz_km between 10000 and 15000) and tipus_nev not like 'RENAULT_%';",
                5));
        kerdesek.add(new Lekerdezes(
                60,
                "Irassa ki az összes olyan megrendelés tételt, amely nincs kifizetve és a kölcsönzési idő 1994. január 1. előtt kezdődik vagy fizetve van és a kölcsönzés 1994. május 1. után esedékes!",
                "select * from rendeles r where (fizetes = 'N' and kolcson_kezdete < '1994-01-01') or (fizetes = 'Y' and kolcson_kezdete > '1994-05-01');",
                13));
        kerdesek.add(new Lekerdezes(
                61,
                "Irassa ki az alkalmazottak nevét nagy kezdőbetűkkel, beosztásukat csupa kis betűvel!",
                "SELECT INITCAP(alk_nev) AS alk_nev,LOWER(beosztas) AS beosztas FROM alkalmazott;",
                2));
        kerdesek.add(new Lekerdezes(
                62,
                "Irassa ki az AUTOK táblájának minden sorából a típusneveket és a rendszámokat úgy, hogy a típus neveket kisbetűssé konvertálja!",
                "select lower(tipus_nev) as tipus_nev,rendszam from tipusok t join autok a on t.id = a.tipusok_id;",
                2));
        kerdesek.add(new Lekerdezes(
                63,
                "Készítsen listát az összes készpénzzel fizető ügyfélről! Az ügyfél nevét, számát és a fizetési módját a következő szöveg után írja ki: 'ÜGYFÉL:'",
                "select * from ugyfelek u where fizetesi_mod = 'K';",
                9));
        kerdesek.add(new Lekerdezes(
                64,
                "Irassa ki az ügyfelek számát, nevét és megbízottját úgy, hogy a megbízott neve nagybetűvel kezdődjön és a többi karaktere kisbetűs legyen vagy 10 db '*' szerepeljen az üres mező helyén!",
                "select ugyfel_szam, ugyfel_nev, coalesce(initcap(megbizott),'**********') as megbizott from ugyfelek u;",
                3));
        kerdesek.add(new Lekerdezes(
                65,
                "A 'minden|szo nagy,betuvel.kezdodik' karaktersorozatra alkalmazzuk az INITCAP függvényt! (DUAL tábla)",
                "SELECT INITCAP('minden|szo nagy,betuvel.kezdodik') as nagybetuk;",
                1));
        kerdesek.add(new Lekerdezes(
                66,
                "Irassa ki az alkalmazottak beosztását kisbetűvel és azt, hogy az alkalmazott neve hány karakterből áll!",
                "select lower (beosztas) as beosztas, length(alk_nev) as alk_nev from alkalmazott;",
                2));
        //kerdesek.add(new Lekerdezes(
                //67,
                //"Irassa ki a beosztásokat, és a beosztások 4-6. karakterét kisbetűssé alakítva!",
                //"select beosztas, lower (substring(beosztas),4,6) as beosztas  from alkalmazott a;",
                //2));
        kerdesek.add(new Lekerdezes(
                68,
                "Irassa ki az autók típusnevét jobbról a '\"' karakterekkel 20 karakter hosszúra kiegészítve!",
                "select rpad(tipus_nev,20,'*') as tipus_nev from tipusok t;",
                1));
        kerdesek.add(new Lekerdezes(
                69,
                "Irassa ki az autók típusnevét balról a '-' karakterekkel 20 karakter hosszúra kiegészítve!",
                "select lpad(tipus_nev,20,'-') as tipus_nev from tipusok t;",
                1));
        kerdesek.add(new Lekerdezes(
                70,
                "Irassa ki a 'KAKAS' karaktersorozatot úgy, hogy balról vágjuk le az 'A' és 'K' karaktereket!",
                "select ltrim('KAKAS','AK') as Ltrim;",
                1));
        kerdesek.add(new Lekerdezes(
                71,
                "Irassa ki az alkalmazottak beosztását jobbról a '\"' karakterekkel 25 karakter hosszúra kiegészítve!",
                "select rpad(beosztas,25,'*') as beosztas from alkalmazott a;",
                1));
        kerdesek.add(new Lekerdezes(
                72,
                "Irassa ki az alkalmazottak beosztását balról a'-' karakterekkel 25 karakter hosszúra kiegészítve!",
                "select lpad(beosztas,25,'-') as beosztas from alkalmazott a;",
                1));
    }

    public ArrayList<Lekerdezes> getKerdesek() {
        return kerdesek;
    }

    public void setKerdesek(ArrayList<Lekerdezes> kerdesek) {
        this.kerdesek = kerdesek;
    }
}
