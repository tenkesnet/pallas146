package org.pallas;

public class HaziMacska extends MacskaFele{

    public HaziMacska(String szin, String élőHely, float suly, boolean agressziv) {
        super(szin, élőHely, suly,agressziv );
      }
}
