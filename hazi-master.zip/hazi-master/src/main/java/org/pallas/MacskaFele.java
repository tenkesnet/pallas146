package org.pallas;

public class MacskaFele {
    String szin;
    String élőHely;
    float suly;
    boolean agressziv;

    public MacskaFele(String szin, String élőHely, float suly, boolean agressziv){

        this.szin = szin;
        this.élőHely= élőHely;
        this.suly = suly;
        this.agressziv = agressziv;
    }

}

