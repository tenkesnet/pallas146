package org.pallas;

public class VadMacska extends MacskaFele {

    public VadMacska(String szin, String élőHely, float suly, boolean agressziv) {
        super(szin, élőHely, suly, agressziv);
    }

}
