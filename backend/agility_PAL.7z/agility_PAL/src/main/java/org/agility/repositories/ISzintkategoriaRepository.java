package org.agility.repositories;

import org.agility.models.Szintkategoria;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ISzintkategoriaRepository extends JpaRepository<Szintkategoria, Integer> {

}
