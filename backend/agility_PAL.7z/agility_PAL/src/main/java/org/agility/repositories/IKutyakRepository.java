package org.agility.repositories;

import org.agility.models.Kutyak;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IKutyakRepository extends JpaRepository<Kutyak, Integer> {

}
