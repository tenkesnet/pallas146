package org.agility.mappers;

import org.agility.dtos.FutamokSzintDTO;
import org.agility.models.Futamok;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

public interface FutamokSzintMapper {
    FutamokSzintMapper MAPPER = Mappers.getMapper(FutamokSzintMapper.class);
    @Mapping(target = "szintkategoriaSzint", source = "szintkategoria.szint")
    FutamokSzintMapper fromFutam (Futamok futamok);
    List<FutamokSzintDTO> fromFutamok (List<Futamok> futamok);

}
