package org.agility.repositories;

import org.agility.models.Szerep;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ISzerepRepository extends JpaRepository<Szerep, Integer> {

}
