package org.agility.dtos;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
@Data
public class FutamokSzintDTO {
    public int id;
    public LocalDate kezdoIdopont;
    public int hiba;
    public BigDecimal ido;
    public int eredmeny;
    public int palyahossz;
    public String szintkategoriaSzint;
}
