package org.agility.repositories;

import org.agility.models.Futamok;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IFutamokRepository extends JpaRepository<Futamok,Integer> {

}
