package org.agility.repositories;

import org.agility.models.Meretkategoria;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IMeretkategoriaRepository extends JpaRepository<Meretkategoria, Integer> {

}
