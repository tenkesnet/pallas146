package org.agility.mappers;

import org.agility.dtos.FutamokMeretDTO;
import org.agility.models.Futamok;
import org.agility.models.Meretkategoria;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

public interface FutamokMeretMapper {
    FutamokMeretMapper MAPPER = Mappers.getMapper(FutamokMeretMapper.class);
    @Mapping(target = "meretkategoriaMeret", source = "meretkategoria.meret")
    FutamokMeretMapper fromMeretkat (Meretkategoria meretkategoria);
    List<FutamokMeretMapper> fromFutamok (List<Futamok> futamok2);
}
