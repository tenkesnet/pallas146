package org.agility;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgilityApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgilityApplication.class, args);
	}

}
