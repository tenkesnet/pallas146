package org.agility.repository;

import org.agility.models.Kutyasok;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IKutyasokRepository extends JpaRepository<Kutyasok,Integer> {
}
