package org.agility.repository;

import org.agility.models.Futamok;
import org.agility.models.Szerep;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IFutamokRepository extends JpaRepository<Futamok,Integer> {
}
