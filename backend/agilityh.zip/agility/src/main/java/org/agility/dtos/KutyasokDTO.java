package org.agility.dtos;

import lombok.Data;

import java.util.Date;
@Data
public class KutyasokDTO {
    private int id;
    private String teljesnev;

    private String cim;

    private int szuldat;

    private int kartyaszam;

    private String szerepnev;


}
