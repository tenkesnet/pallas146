package org.agility.repository;

import org.agility.models.Kutyafajtak;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IKutyafajtakRepository extends JpaRepository<Kutyafajtak,Integer> {
}
