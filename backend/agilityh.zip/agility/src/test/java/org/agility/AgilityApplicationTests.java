package org.agility;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgilityApplicationTests {

	@Test
	void contextLoads() {
	}

}
